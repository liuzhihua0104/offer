<template>
	<div>
		这是home组件
	</div>
</template>