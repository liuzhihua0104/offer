<template>
  <div id="app">
      


  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
  	 return {
  	 	obj:{a:1}
  	 }
  },
  mounted(){
  	console.log(this.obj);
  }
}
</script>

