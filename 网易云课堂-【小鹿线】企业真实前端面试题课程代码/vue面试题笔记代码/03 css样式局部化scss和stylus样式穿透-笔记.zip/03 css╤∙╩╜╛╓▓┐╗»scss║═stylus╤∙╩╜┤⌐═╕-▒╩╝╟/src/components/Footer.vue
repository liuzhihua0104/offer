<template>
	<div class='main'>
		这是footer
	</div>
</template>