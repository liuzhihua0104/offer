<template>
  <div id="app">
        
    <Header></Header>
    <Footer></Footer>

  </div>
</template>



<script>
import Header from '@/components/Header'
import Footer from '@/components/Footer'
export default {
  name: 'App',
  components:{
    Header,
    Footer
  }
}
</script>

