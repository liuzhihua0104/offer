<template>
	
	<div>
		这是首页
	</div>

	
</template>

<script type="text/javascript">
export default {
	mounted(){

	},
	beforeRouteEnter(){
		window.document.title = '首页-Home'
	}
}
</script>