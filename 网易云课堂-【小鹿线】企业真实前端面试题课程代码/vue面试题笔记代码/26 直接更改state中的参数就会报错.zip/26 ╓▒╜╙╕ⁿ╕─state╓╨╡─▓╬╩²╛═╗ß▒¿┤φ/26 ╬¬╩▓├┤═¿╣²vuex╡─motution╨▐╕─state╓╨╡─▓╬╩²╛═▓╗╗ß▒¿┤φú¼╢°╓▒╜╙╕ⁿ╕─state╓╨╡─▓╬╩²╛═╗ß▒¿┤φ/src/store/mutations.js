export default {

	changeBtn(state){
			
		state.city = 'ooooooooxxxxxxxx';

	}

}