import {CHANGE_CITY} from './mutations-types'
export default {
	[CHANGE_CITY](state){
		state.city = '上海'
	}
}