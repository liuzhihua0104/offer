export default {
	city:"北京",
	arr:['a','b','c','d']
}