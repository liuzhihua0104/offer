<template>
	<div>
		首页
		<hr />
		<router-link to='/news'>新闻页</router-link>
	</div>
</template>