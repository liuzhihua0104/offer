<template>
	<div>
		新闻页
		<hr />
	</div>
</template>

<script type="text/javascript">
export default {
	mounted(){
		console.log(  this.$route, this.$router )
	}
}
</script>